for dir in $(lsd); do cd $dir; for file in $(ls *.p); do python ../../../tests/network_vmd.py ../../../data/frames_apo_noH/1frame_1.pdb $file $file.tcl; done; cd ..; done
